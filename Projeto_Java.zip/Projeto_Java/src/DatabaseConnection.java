import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class DatabaseConnection {

    private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=HealthTech;integratedSecurity=true";
    private static final String USER = "";
    private static final String PASSWORD = "";
    
    public static Connection connect() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao conectar ao banco de dados.");
        }
    }
    public static void insertPaciente(String nome, String cpf, String dataNascimento, String telefone, String email, String vulnerabilidade) {
        String sql = "INSERT INTO paciente (nome, cpf, data_nascimento, telefone, email, vulnerabilidade) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, cpf);
            stmt.setString(3, dataNascimento);
            stmt.setString(4, telefone);
            stmt.setString(5, email);
            stmt.setString(6, vulnerabilidade);
            stmt.executeUpdate();
            System.out.println("Paciente inserido com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Erro ao inserir paciente: " + e.getMessage());
        }
    }
    public static int realizarTesteVulnerabilidade() {
        Scanner entrada = new Scanner(System.in);
        int pontuacao = 0;
        System.out.println("Responda as seguintes perguntas com 'sim' ou 'não':");
        pontuacao += perguntar(entrada, "1. Você se sente mal consigo mesmo?", 1);
        pontuacao += perguntar(entrada, "2. Você tem pensamentos ruins contra si?", 2);
        pontuacao += perguntar(entrada, "3. Você já executou alguma ação contra si?", 2);
        pontuacao += perguntar(entrada, "4. Você já tentou fazer algo contra si?", 2);
        pontuacao += perguntar(entrada, "5. Você já tentou tirar a própria vida?", 3);
        System.out.println("Teste de vulnerabilidade concluído. Pontuação total: " + pontuacao);
        return pontuacao;
    }
    private static int perguntar(Scanner scanner, String pergunta, int peso) {
        while (true) {
            System.out.print(pergunta + " (sim/não): ");
            String resposta = scanner.nextLine().trim().toLowerCase();
            if (resposta.equals("sim")) {
                return peso;
            } else if (resposta.equals("não")) {
                return 0;
            } else {
                System.out.println("Resposta inválida. Por favor, responda com 'sim' ou 'não'.");
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Inserção de Paciente ===");

        System.out.print("Nome: ");
        String nome = scanner.nextLine();

        System.out.print("CPF: ");
        String cpf = scanner.nextLine();

        System.out.print("Data de Nascimento (YYYY-MM-DD): ");
        String dataNascimento = scanner.nextLine();

        System.out.print("Telefone: ");
        String telefone = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.println("=== Realizando Teste de Vulnerabilidade ===");
        int pontuacao = realizarTesteVulnerabilidade();
        String vulnerabilidade = (pontuacao >= 5) ? "Procure ajuda psicológica agora!" : (pontuacao < 5 && pontuacao > 1 ? "Fique atento(a) e se precisar, procure ajuda!" : "Está tudo bem!");

        insertPaciente(nome, cpf, dataNascimento, telefone, email, vulnerabilidade);
    }
}
